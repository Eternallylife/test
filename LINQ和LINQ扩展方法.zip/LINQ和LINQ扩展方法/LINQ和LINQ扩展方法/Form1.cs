﻿using LINQ和LINQ扩展方法.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ和LINQ扩展方法
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // 1. where条件，查询的逻辑和条件， 扩展where()
            /*List<int> list1 = new List<int>() { 6, 4, 2, 7, 9, 0 };
            IEnumerable<int> query = list1.Where(c => c >= 1 && c <= 5);
            for (int i = 0; i <= query.Count()-1; i++)
            {
                Console.WriteLine(query.ToArray()[i]);
            }

            // LINQ是强类型，会根据数据源的类型推断出来查询结果的类型。
            IEnumerable<int> query2 = from item in list1
                                     //where item >= 1 && item <= 5  // 并列 && ，或者|| 等于== 不等于!=, >,<,>=,<=,!
                                     //where !(item % 2 == 0)
                                     //where !GetEven(item)
                                      select item;

            for (int i = 0; i <= query2.Count() - 1; i++)
            {
                Console.WriteLine(query2.ToArray()[i]);
            }

            List<string> list2 = new List<string>() { "abc", "ab", "bc", "cad" };

            IEnumerable<string> query3 = from item in list2
                         where item.Contains("a")
                         select item;
            for (int i = 0; i <= query3.Count() - 1; i++)
            {
                Console.WriteLine(query3.ToArray()[i]);
            }*/


            // 2. 对查询结果做筛选（显示和隐藏列）  Select()扩展方法和select子名类似， SelectMany()类似于两个from
            /*List<int> list1 = new List<int>() { 1, 2, 3 };
            List<int> list2 = new List<int>() { 4, 5, 6 };

            var result1 = list1.Select(item=>item);
            var result2 = from item in list1
                          select item;

            // 查询多个数据源，item指的是list1中的每一项
            var result3 = list1.SelectMany(item => list2);

            // Data To Object==DTO把查询出来的数据转换成对象，目的：访问时方便，打点调用
            var result4 = from item in list1
                          from value in list2
                          //select new { item,value};
                          select new IntObject() { Key = item, Value = value };

            List<IntObject> result5 = result4.ToList();
            for (int i = 0; i < result5.Count(); i++)
            {
                IntObject obj = result5[i];
                Console.WriteLine($"Key:{obj.Key},Value:{obj.Value}");
            }*/

            // 3. 分组  GroupBy(), group子名，into子句
            // GroupBy（）本身具有延迟执行的特性，而ToLookup()没有。

            /*List<string> sequence = new List<string>() { "a", "b", "b", "c", "c" };
            var group = sequence.GroupBy(o => o);  // 默认GroupBy统计的是Count
            foreach (var g in group)
            {
                Console.WriteLine("Key:{0}, Count:{1}", g.Key, g.Count());
            }

            var result = from item in sequence
                         group item by item into groupResult  // into子句：把分组的结果保存到一个变量中，方便取分组的结果
                         select groupResult;

            foreach (var item in result)
            {
                Console.WriteLine($"Key:{item.Key}, Count:{item.Count()}");
            }

            var result2 = from item in sequence
                          group item by item;

            foreach (var item in result2)
            {
                Console.WriteLine($"Key:{item.Key}, Count:{item.Count()}");
            }*/

            // 4. ToLookup()   相当于group by into    GroupBy()相当于group by 
            /*var nameValuesGroup = new Person[]
            {
                 new Person(){Name="张三", Score=65, Group="A"},
                 new Person(){Name="李四", Score=75, Group="B"},
                 new Person(){Name="王五", Score=85, Group="A"},
            };
            var lookupValues = nameValuesGroup.ToLookup(p => p.Group);
            foreach (var g in lookupValues)  // 循环每一组
            {
                Console.WriteLine("组名: {0}", g.Key);
                foreach (var p in g) // 循环一组中的多个人
                {
                    Console.WriteLine("姓名:{0},分数:{1},属于的组{2}", p.Name, p.Score,p.Group);
                }
            }

            var result = from p in nameValuesGroup
                         group p by p.Group into g
                         select g;

            foreach (var g in result)  // 循环每一组
            {
                Console.WriteLine("组名: {0}", g.Key);
                foreach (var p in g) // 循环一组中的多个人
                {
                    Console.WriteLine("姓名:{0},分数:{1},属于的组{2}", p.Name, p.Score, p.Group);
                }
            }*/

            // 5. 表联接（连接）  Join() 相当于 join  on  equals  默认是inner join内联系  JoinGroup()是左外联
            /*List<Student> students = new List<Student>()
            {
                new Student(){StudentId=1,StudentName="张三1",ClassRoomId=1},
                new Student(){StudentId=2,StudentName="张三2",ClassRoomId=1},
                new Student(){StudentId=3,StudentName="张三3",ClassRoomId=2},
                new Student(){StudentId=4,StudentName="张三4",ClassRoomId=2},
                new Student(){StudentId=5,StudentName="张三5",ClassRoomId=3},

            };

            List<ClassRoom> classRooms = new List<ClassRoom>()
            {
                new ClassRoom(){ClassRoomId=1,ClassRoomName="班级1"},
                new ClassRoom(){ClassRoomId=2,ClassRoomName="班级2"},
                new ClassRoom(){ClassRoomId=4,ClassRoomName="班级4"},

            };

            // 参数1：联接的第二个数据源
            // 参数2：左表的关联逻辑
            // 参数3：右表的关联逻辑
            // 参数4：关联两个表后，筛选的结果
            var result = students.Join(classRooms, s => s.ClassRoomId, cr => cr.ClassRoomId,
                (s, cr) =>
                new StudentDTO()
                {
                    StudentId = s.StudentId,
                    StudentName = s.StudentName,
                    ClassRoomId = s.ClassRoomId,
                    ClassRoomName = cr.ClassRoomName
                });

            var result1 = from s in students
                          join cr in classRooms on s.ClassRoomId equals cr.ClassRoomId
                          select new StudentDTO()
                          {
                              StudentId = s.StudentId,
                              StudentName = s.StudentName,
                              ClassRoomId = s.ClassRoomId,
                              ClassRoomName = cr.ClassRoomName
                          };


            var result2 = students.GroupJoin(classRooms, s => s.ClassRoomId, cr => cr.ClassRoomId,
                (s, cr) =>
                new 
                {
                    StudentId = s.StudentId,
                    StudentName = s.StudentName,
                    ClassRoomId = s.ClassRoomId,
                    Count = cr.Count()  // GroupJoin()默认得到右表数量，不能拿右表中的列。
                });

            var result3 = from s in students
                          join cr in classRooms on s.ClassRoomId equals cr.ClassRoomId into joinResult
                          select new
                          {
                              StudentId = s.StudentId,
                              StudentName = s.StudentName,
                              ClassRoomId = s.ClassRoomId,
                              Count = joinResult.Count()
                          };


            var result4 = students.Join(classRooms, s => s.ClassRoomId, cr => cr.ClassRoomId, 
                (s, cr) => 
                new StudentDTO() {
                    StudentId = s.StudentId,
                    StudentName = s.StudentName,
                    ClassRoomId = s.ClassRoomId,
                    ClassRoomName = cr.ClassRoomName
                })
                // 再GroupJoin时，Join()后生成的结果当成左表
                .GroupJoin(classRooms, sdto => sdto.ClassRoomId, cr => cr.ClassRoomId,
                (sdto, cr) =>
                new
                {
                    StudentId = sdto.StudentId,
                    StudentName = sdto.StudentName,
                    ClassRoomId = sdto.ClassRoomId,
                    ClassRoom = sdto.ClassRoomName,
                    Count = cr.Count()  // GroupJoin()默认得到右表数量，不能拿右表中的列。
                });

            var result5 = from s in students
                          join cr in classRooms on s.ClassRoomId equals cr.ClassRoomId into joinResult
                          from jr in joinResult
                          join cr2 in classRooms on jr.ClassRoomId equals cr2.ClassRoomId into joinResult2
                          //orderby jr.ClassRoomId ascending,jr.ClassRoomName descending
                          select new {  
                            StudentId = s.StudentId,
                            StudentName = s.StudentName,
                            ClassRoomId = s.ClassRoomId,
                            ClassRoomName = jr.ClassRoomName,
                            Count = joinResult2.Count()
                          };*/

            //students.OrderBy(s => s.StudentName).OrderBy(s => s.StudentId).OrderByDescending(s => s.ClassRoomId);
            //students.OrderBy(s => s.StudentName).ThenBy(s => s.StudentId).ThenByDescending(s => s.ClassRoomId);

            // 6.LINQ扩展方法之聚合方法：https://www.bilibili.com/read/cv16254091/


            // 7.分页
            List<Student> students = new List<Student>()
            {
                new Student(){StudentId=1,StudentName="张三1",ClassRoomId=1},
                new Student(){StudentId=2,StudentName="张三2",ClassRoomId=1},
                new Student(){StudentId=3,StudentName="张三3",ClassRoomId=2},
                new Student(){StudentId=4,StudentName="张三4",ClassRoomId=2},
                new Student(){StudentId=5,StudentName="张三5",ClassRoomId=3},
            };

            var result1 = students.OrderByDescending(s => s.StudentId).Skip(0);
            var result2 = students.OrderBy(s => s.StudentId).SkipWhile(u => u.StudentId == 1);

            // 
            var firstLastItems = new[] { "zero", "two", "three", "four", "five" };
            string firstContainsO = firstLastItems.First(s => s.Contains('o'));
            string lastContainsO = firstLastItems.Last(s => s.Contains('o'));

            string result3 = firstLastItems.Where(s => s.Contains("a")).FirstOrDefault();
            string result4 = firstLastItems.Where(s => s.Contains("a")).LastOrDefault();

            // IEnumerable没有索引器，只能带索引器，才能使用[索引]  ToArray(),ToList()
            IEnumerable<string> result5 =  firstLastItems.Where(s => s.Contains("o"));
           string result6 =  result5.ElementAt(1);

        }

        private bool GetEven(int num)
        {
            return num % 2 == 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindDataGridView();
        }

        private int currentPage = 1;
        private int pageSize = 2;
        private int totalPage = 0;
        private void BindDataGridView()
        {
            using (var context = new db_awardEntities())
            {
                // LINQ语法和LINQ扩展方法混用，实现分页
                IQueryable<UserInfo> query = from u in context.UserInfoes
                                             orderby u.UserId ascending
                                             select u;

                // 为啥where条件添加到query上。因为查询结果 和 总页数两个查询共用一个查询条件
                if (!string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    query = query.Where(u => u.Account.Contains(textBox1.Text));
                }

                if (!string.IsNullOrWhiteSpace(dateTimePicker1.Text))
                {
                    DateTime dt = DateTime.Parse(dateTimePicker1.Value.ToString("yyyy-MM-dd") + " 00:00:00");
                    query = query.Where(u => u.CreateTime >= dt);
                }

                if (!string.IsNullOrWhiteSpace(dateTimePicker2.Text))
                {
                    DateTime dt = DateTime.Parse(dateTimePicker2.Value.ToString("yyyy-MM-dd") + " 23:59:59");
                    query = query.Where(u => u.CreateTime <= dt);
                }

                if (comboBox1.SelectedIndex != -1 && comboBox1.SelectedIndex != 0)
                {
                    int status = Convert.ToInt32(comboBox1.Text);
                    query = query.Where(u => u.Status == status);
                }

                // Skip跳，跨越， Take拿，取，注意：分页前先排序
                IQueryable<UserInfo> query2 = query.Skip((currentPage - 1) * pageSize).Take(pageSize);

                totalPage = query.Count() % pageSize == 0 ? query.Count() / pageSize : query.Count() / pageSize + 1;

                dataGridView1.DataSource = query2.ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            currentPage = 1;
            BindDataGridView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
            }
            else
            {
                currentPage = 1;
            }
            BindDataGridView();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (currentPage < totalPage)
            {
                currentPage++;
            }
            else
            {
                currentPage = totalPage;
            }
            BindDataGridView();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            currentPage = totalPage;
            BindDataGridView();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            currentPage = 1;
            BindDataGridView();
        }
    }
}
