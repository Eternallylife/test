﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ和LINQ扩展方法.Models
{
    public class StudentDTO
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int ClassRoomId { get; set; }
        public string ClassRoomName { get; set; }
    }
}
