﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ和LINQ扩展方法.Models
{
    public class IntObject
    {
        public int Key { get; set; }
        public int Value { get; set; }

    }
}
